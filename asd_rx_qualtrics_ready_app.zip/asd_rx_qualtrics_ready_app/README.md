# ASD-Rx Guide Qualtrics-Ready App

Open `index.html` locally or upload it to GitHub Pages.

## Add Qualtrics links later
In `index.html`, find:

const QUALTRICS_PRETEST_URL = "";
const QUALTRICS_POSTTEST_URL = "";

Paste your Qualtrics anonymous links between the quotation marks.

## Embed inside the app
To embed the surveys directly inside the app, change:

const EMBED_QUALTRICS_FORMS = false;

to:

const EMBED_QUALTRICS_FORMS = true;

If left false, the app opens Qualtrics in a new browser tab.
